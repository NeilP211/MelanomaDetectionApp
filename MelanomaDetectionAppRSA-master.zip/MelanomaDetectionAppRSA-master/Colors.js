export default {
	darkPurple: "#301934",
	white: "#FFFFFF",
	yellow: "#FFFF00",
};
